#!/bin/sh

# Scripts placed within this directory are called immediately prior to launching the Phoronix Test Suite for the first time.

# hooks/startup are useful if wanting to pre-seed certain environment variables prior to executing the Phoronix Test Suite, etc.

# No special environment variables are passed/pre-seeded prior to running the scripts in this folder.

